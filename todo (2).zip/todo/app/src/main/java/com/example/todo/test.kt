package com.example.todo

import android.content.SharedPreferences
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class Test : AppCompatActivity() {
    private lateinit var textViewName: TextView
    private lateinit var textViewEmail: TextView
    private lateinit var textViewPassword: TextView
    private lateinit var btnLogout: Button

    private lateinit var sharedPreferences: SharedPreferences
    private val SHARED_PREF_NAME = "tickTask"
    private val KEY_NAME = "name"
    private val KEY_EMAIL = "email"
    private val KEY_PASSWORD = "password"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_test)

        textViewName = findViewById(R.id.name)
        textViewEmail = findViewById(R.id.email)
        textViewPassword = findViewById(R.id.password)
        btnLogout = findViewById(R.id.button)

        sharedPreferences = getSharedPreferences(SHARED_PREF_NAME, MODE_PRIVATE)

        val name = sharedPreferences.getString(KEY_NAME, null)
        val email = sharedPreferences.getString(KEY_EMAIL, null)
        val password = sharedPreferences.getString(KEY_PASSWORD, null)

        if (name != null || email != null || password != null) {
            textViewName.text = "Name = $name"
            textViewEmail.text = "Email = $email"
            textViewPassword.text = "Password = $password"
        }

        btnLogout.setOnClickListener {
            with(sharedPreferences.edit()) {
                clear()
                apply()
            }
            finish()
            Toast.makeText(applicationContext, "Logout Successfully", Toast.LENGTH_SHORT).show()
        }
    }
}

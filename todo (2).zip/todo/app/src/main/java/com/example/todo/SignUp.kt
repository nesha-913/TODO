package com.example.todo

import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class SignUp : AppCompatActivity() {

    private lateinit var btnSignup: Button
    private lateinit var btnLogin: TextView
    private lateinit var editTextName: EditText
    private lateinit var editTextEmail: EditText
    private lateinit var editTextPassword: EditText
    private lateinit var sharedPreferences: SharedPreferences

    // Shared Preferences keys
    private val SHARED_PREF_NAME = "TaskTrack"
    private val KEY_NAME = "name"
    private val KEY_EMAIL = "email"
    private val KEY_PASSWORD = "password"
    private val KEY_IS_LOGGED_IN = "isLoggedIn"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sign_up)

        // Direct to login activity
        btnLogin = findViewById(R.id.btn_login)
        btnLogin.setOnClickListener {
            val intent = Intent(applicationContext, Login::class.java)
            startActivity(intent)
        }

        // Handle registration
        btnSignup = findViewById(R.id.btn_signup)
        editTextName = findViewById(R.id.name)
        editTextEmail = findViewById(R.id.email)
        editTextPassword = findViewById(R.id.password)
        sharedPreferences = getSharedPreferences(SHARED_PREF_NAME, MODE_PRIVATE)

        btnSignup.setOnClickListener {
            // Get user input
            val name = editTextName.text.toString()
            val email = editTextEmail.text.toString()
            val password = editTextPassword.text.toString()

            // Validate user input
            when {
                name.isEmpty() || email.isEmpty() || password.isEmpty() -> {
                    Toast.makeText(applicationContext, "Please fill all fields", Toast.LENGTH_SHORT).show()
                }
                !android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches() -> {
                    Toast.makeText(applicationContext, "Please enter a valid email address", Toast.LENGTH_SHORT).show()
                }
                else -> {
                    // Save data to SharedPreferences
                    with(sharedPreferences.edit()) {
                        putString(KEY_NAME, name)
                        putString(KEY_EMAIL, email)
                        putString(KEY_PASSWORD, password)
                        putBoolean(KEY_IS_LOGGED_IN, true) // Set login flag
                        apply()
                    }

                    // Clear tasks data
                    clearTasksSharedPreferences()

                    // Start NavigationView activity
                    val intent = Intent(applicationContext, NavigationView::class.java)
                    startActivity(intent)
                    finish()

                    Toast.makeText(applicationContext, "Account Created Successfully", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun clearTasksSharedPreferences() {
        with(sharedPreferences.edit()) {
            remove("tasks")
            apply()
        }
    }
}
